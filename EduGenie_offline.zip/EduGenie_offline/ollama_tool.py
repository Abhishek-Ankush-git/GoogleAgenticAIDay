import requests
import json
import logging

logger = logging.getLogger(__name__)

def generate_text_with_ollama(prompt: str, model: str = "llama2") -> str:
    """
    Generates text using the Ollama API.

    Args:
        prompt: The text prompt to send to Ollama.
        model: The name of the Ollama model to use.

    Returns:
        The generated text from Ollama, or None if an error occurred.
    """
    try:
        url = "http://localhost:11434/api/generate"  # Ollama API endpoint
        headers = {"Content-Type": "application/json"}
        data = {
            "model": model,
            "prompt": prompt,
            "stream": False  # Set to True for streaming
        }

        response = requests.post(url, headers=headers, data=json.dumps(data))
        response.raise_for_status()  # Raise HTTPError for bad responses

        json_response = response.json()
        return json_response["response"]

    except requests.exceptions.RequestException as e:
        logger.error(f"Error communicating with Ollama: {e}")
        return None
    except KeyError as e:
        logger.error(f"Error parsing Ollama response: {e}")
        logger.error(f"Response content: {response.content}")
        return None
    except Exception as e:
        logger.exception(f"An unexpected error occurred: {e}")
        return None