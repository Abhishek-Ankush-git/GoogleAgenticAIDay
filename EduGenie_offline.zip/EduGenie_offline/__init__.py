# from google.adk.tools import BaseTool 
# from .ollama_tool import generate_text_with_ollama
# from typing import Optional

# class OllamaTool(BaseTool):
#     """
#     A custom tool that uses Ollama to generate text.
#     """

#     def __init__(self, name: str, description: str):
#         super().__init__(name=name, description=description)

#     async def run(self, prompt: str, model: Optional[str] = None) -> str:
#         """
#         Runs the tool and returns the generated text.

#         Args:
#             prompt: The text prompt to send to Ollama.
#             model: The name of the Ollama model to use.

#         Returns:
#             The generated text from Ollama, or an error message if something went wrong.
#         """
#         if model is None:
#             model = "llama2"  # Default model

#         generated_text = generate_text_with_ollama(prompt, model)

#         if generated_text:
#             return generated_text
#         else:
#             return "Error: Failed to generate text with Ollama."

from . import agent