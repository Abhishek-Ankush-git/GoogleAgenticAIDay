from google.adk.agents import Agent
from google.adk.models.lite_llm import LiteLlm

root_agent = Agent(
    name='EduGenie_local',
    model=LiteLlm(
        model='ollama/gemma3n:e4b',  # Or 'ollama/qwen3:14b', etc.
        api_base='http://localhost:11434',
        stream=True,  # Optional: for streaming responses
    ),
    description='An agent powered by a local Ollama model.',
    instruction="""
    You are a helpful assistant that provides concise and accurate information.
    """,
)

# You can also add tools if your agent needs to perform actions
# from google.adk.tools import FunctionTool
# def get_current_time(city: str) -> str:
#     # Your logic to get time
#     return f"The time in {city} is currently..."
#
# root_agent.tools = [FunctionTool(func=get_current_time)]