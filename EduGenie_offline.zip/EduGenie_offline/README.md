# EduGenie Offline

A local educational AI agent powered by Ollama, designed to provide educational assistance without requiring internet connectivity.

## Overview

EduGenie Offline is a local AI agent that leverages Ollama to provide educational assistance. It uses the Google ADK (Agent Development Kit) framework to create a conversational AI agent that can run entirely offline on your local machine.

## Features

- **Offline Operation**: Works completely offline using local Ollama models
- **Educational Focus**: Designed specifically for educational assistance
- **Streaming Support**: Optional streaming responses for real-time interaction
- **Customizable Models**: Support for various Ollama models (Gemma, Qwen, Llama, etc.)
- **Error Handling**: Robust error handling for API communication

## Components

### 1. Agent (`agent.py`)
The main agent configuration using Google ADK:
- Uses `ollama/gemma3n:e4b` model by default
- Configured for local Ollama server at `http://localhost:11434`
- Supports streaming responses
- Can be extended with custom tools

### 2. Ollama Tool (`ollama_tool.py`)
A utility module for communicating with Ollama:
- `generate_text_with_ollama()`: Main function for text generation
- Handles API communication with local Ollama server
- Comprehensive error handling and logging
- Support for different models and streaming

### 3. Module Initialization (`__init__.py`)
Module initialization and exports:
- Currently exports the agent module
- Contains commented code for potential OllamaTool implementation

## Prerequisites

1. **Ollama Installation**: Install Ollama on your system
   ```bash
   # macOS
   curl -fsSL https://ollama.ai/install.sh | sh
   
   # Linux
   curl -fsSL https://ollama.ai/install.sh | sh
   
   # Windows
   # Download from https://ollama.ai/download
   ```

2. **Python Dependencies**:
   ```bash
   pip install google-adk requests
   ```

3. **Ollama Model**: Pull a model for local use
   ```bash
   ollama pull gemma3n:e4b
   # or
   ollama pull qwen3:14b
   ```

## Setup

1. **Start Ollama Server**:
   ```bash
   ollama serve
   ```

2. **Verify Ollama is Running**:
   ```bash
   curl http://localhost:11434/api/tags
   ```

3. **Import and Use the Agent**:
   ```python
   from app.EduGenie_offline import agent
   
   # The agent is configured and ready to use
   root_agent = agent.root_agent
   ```

## Usage

### Basic Usage
```python
from app.EduGenie_offline import agent

# Use the configured agent
response = await root_agent.run("Explain quantum physics in simple terms")
print(response)
```

### Using the Ollama Tool Directly
```python
from app.EduGenie_offline.ollama_tool import generate_text_with_ollama

# Generate text with a specific model
response = generate_text_with_ollama(
    prompt="What is machine learning?",
    model="gemma3n:e4b"
)
print(response)
```

### Customizing the Agent
```python
from app.EduGenie_offline.agent import root_agent
from google.adk.tools import FunctionTool

# Add custom tools
def get_math_help(question: str) -> str:
    return f"Here's help with: {question}"

root_agent.tools = [FunctionTool(func=get_math_help)]
```

## Configuration

### Model Selection
You can change the model in `agent.py`:
```python
model=LiteLlm(
    model='ollama/qwen3:14b',  # Change to your preferred model
    api_base='http://localhost:11434',
    stream=True,
)
```

### Available Models
- `ollama/gemma3n:e4b` (default)
- `ollama/qwen3:14b`
- `ollama/llama2:7b`
- `ollama/codellama:7b`
- And many more available on Ollama

## Error Handling

The module includes comprehensive error handling:
- Network connectivity issues
- Invalid API responses
- Model loading errors
- JSON parsing errors

All errors are logged for debugging purposes.

## Development

### Adding New Tools
```python
from google.adk.tools import FunctionTool

def custom_educational_tool(topic: str) -> str:
    # Your custom logic here
    return f"Educational content about {topic}"

root_agent.tools.append(FunctionTool(func=custom_educational_tool))
```

### Extending the Agent
```python
# Modify the agent's instruction for specific use cases
root_agent.instruction = """
You are an expert educational assistant specializing in STEM subjects.
Provide clear, accurate explanations with examples when possible.
"""
```

## Troubleshooting

### Common Issues

1. **Ollama Connection Error**:
   - Ensure Ollama is running: `ollama serve`
   - Check if port 11434 is available
   - Verify firewall settings

2. **Model Not Found**:
   - Pull the required model: `ollama pull gemma3n:e4b`
   - Check available models: `ollama list`

3. **Memory Issues**:
   - Use smaller models for limited RAM
   - Consider using quantized models

## License

This module is part of the EduGenie project and follows the same licensing terms.

## Contributing

When contributing to this module:
1. Ensure all changes work offline
2. Test with different Ollama models
3. Update documentation for new features
4. Follow the existing code style and patterns 