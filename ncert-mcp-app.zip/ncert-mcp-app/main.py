from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import requests
from bs4 import BeautifulSoup
import aiofiles
import os
import json
import asyncio
from pathlib import Path
import logging
from datetime import datetime
import re

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="NCERT MCP Server",
    description="Model Context Protocol server for NCERT website integration",
    version="1.0.0"
)

# Data models
class SyllabusRequest(BaseModel):
    class_name: str
    subject: Optional[str] = None

class LearningPlanRequest(BaseModel):
    class_name: str
    subject: str

class CourseContentRequest(BaseModel):
    class_name: str
    subject: str
    chapter: Optional[str] = None

class BookDownloadRequest(BaseModel):
    class_name: str
    subject: str
    book_type: str = "textbook"  # textbook, workbook, etc.

class NCERTData:
    def __init__(self):
        self.base_url = "https://ncert.nic.in"
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        self.download_dir = Path("downloads")
        self.download_dir.mkdir(exist_ok=True)

    async def get_syllabus(self, class_name: str, subject: Optional[str] = None) -> Dict[str, Any]:
        """Fetch syllabus information from NCERT website"""
        try:
            # NCERT syllabus URL structure
            url = f"{self.base_url}/syllabus"
            response = self.session.get(url)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extract syllabus information
            syllabus_data = {
                "class": class_name,
                "subject": subject,
                "syllabus_url": url,
                "topics": [],
                "last_updated": datetime.now().isoformat()
            }
            
            # Parse syllabus content (this is a simplified version)
            # In a real implementation, you would need to navigate to specific class/subject pages
            syllabus_data["topics"] = self._extract_syllabus_topics(soup, class_name, subject)
            
            return syllabus_data
            
        except Exception as e:
            logger.error(f"Error fetching syllabus: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to fetch syllabus: {str(e)}")

    async def get_learning_plan(self, class_name: str, subject: str) -> Dict[str, Any]:
        """Fetch learning plan for a specific class and subject"""
        try:
            # This would typically involve navigating to specific NCERT pages
            # For now, we'll create a structured learning plan
            learning_plan = {
                "class": class_name,
                "subject": subject,
                "plan": {
                    "duration": "Academic Year",
                    "units": [
                        {
                            "unit": 1,
                            "title": "Introduction",
                            "duration": "2 weeks",
                            "objectives": ["Basic concepts", "Foundation building"],
                            "activities": ["Classroom discussions", "Practical exercises"]
                        },
                        {
                            "unit": 2,
                            "title": "Core Concepts",
                            "duration": "4 weeks",
                            "objectives": ["Deep understanding", "Application"],
                            "activities": ["Problem solving", "Group projects"]
                        }
                    ],
                    "assessment": ["Periodic tests", "Final examination"],
                    "resources": ["NCERT textbooks", "Digital content", "Practice worksheets"]
                }
            }
            
            return learning_plan
            
        except Exception as e:
            logger.error(f"Error fetching learning plan: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to fetch learning plan: {str(e)}")

    async def get_course_content(self, class_name: str, subject: str, chapter: Optional[str] = None) -> Dict[str, Any]:
        """Fetch course content for a specific class, subject, and optionally chapter"""
        try:
            # This would involve scraping specific NCERT content pages
            content = {
                "class": class_name,
                "subject": subject,
                "chapter": chapter,
                "content": {
                    "overview": f"Course content for {class_name} {subject}",
                    "chapters": [
                        {
                            "chapter_number": 1,
                            "title": "Introduction to the Subject",
                            "topics": ["Basic concepts", "Historical background", "Current relevance"],
                            "learning_outcomes": ["Understanding fundamentals", "Application in real life"],
                            "exercises": ["Multiple choice questions", "Short answer questions", "Long answer questions"]
                        },
                        {
                            "chapter_number": 2,
                            "title": "Advanced Concepts",
                            "topics": ["Complex theories", "Practical applications", "Case studies"],
                            "learning_outcomes": ["Critical thinking", "Problem solving"],
                            "exercises": ["Analytical questions", "Project work", "Presentations"]
                        }
                    ],
                    "additional_resources": ["Video lectures", "Interactive simulations", "Reference materials"]
                }
            }
            
            return content
            
        except Exception as e:
            logger.error(f"Error fetching course content: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to fetch course content: {str(e)}")

    async def get_books(self, class_name: str, subject: str) -> Dict[str, Any]:
        """Fetch available books for a specific class and subject"""
        try:
            # This would involve scraping NCERT's book catalog
            books_data = {
                "class": class_name,
                "subject": subject,
                "books": [
                    {
                        "title": f"{subject} Textbook for Class {class_name}",
                        "type": "textbook",
                        "language": "English",
                        "format": ["PDF", "EPUB"],
                        "download_url": f"/books/{class_name}/{subject}/textbook",
                        "description": f"Main textbook for {subject} in Class {class_name}"
                    },
                    {
                        "title": f"{subject} Workbook for Class {class_name}",
                        "type": "workbook",
                        "language": "English",
                        "format": ["PDF"],
                        "download_url": f"/books/{class_name}/{subject}/workbook",
                        "description": f"Practice workbook for {subject} in Class {class_name}"
                    },
                    {
                        "title": f"{subject} Teacher's Guide for Class {class_name}",
                        "type": "teacher_guide",
                        "language": "English",
                        "format": ["PDF"],
                        "download_url": f"/books/{class_name}/{subject}/teacher_guide",
                        "description": f"Teacher's guide for {subject} in Class {class_name}"
                    }
                ]
            }
            
            return books_data
            
        except Exception as e:
            logger.error(f"Error fetching books: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to fetch books: {str(e)}")

    async def download_book(self, class_name: str, subject: str, book_type: str) -> Dict[str, Any]:
        """Download a specific book"""
        try:
            # Create download directory structure
            download_path = self.download_dir / class_name / subject
            download_path.mkdir(parents=True, exist_ok=True)
            
            # Simulate book download (in real implementation, this would download from NCERT)
            filename = f"{subject}_{book_type}_{class_name}.pdf"
            file_path = download_path / filename
            
            # Create a dummy PDF file for demonstration
            await self._create_dummy_pdf(file_path)
            
            download_info = {
                "class": class_name,
                "subject": subject,
                "book_type": book_type,
                "filename": filename,
                "file_path": str(file_path),
                "file_size": file_path.stat().st_size if file_path.exists() else 0,
                "download_time": datetime.now().isoformat(),
                "status": "completed"
            }
            
            return download_info
            
        except Exception as e:
            logger.error(f"Error downloading book: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to download book: {str(e)}")

    def _extract_syllabus_topics(self, soup: BeautifulSoup, class_name: str, subject: Optional[str] = None) -> List[Dict[str, Any]]:
        """Extract syllabus topics from the parsed HTML"""
        topics = []
        # This is a simplified extraction - in reality, you'd need to parse specific NCERT syllabus pages
        topics = [
            {
                "unit": 1,
                "title": "Introduction and Basic Concepts",
                "topics": ["Fundamental principles", "Historical development", "Current applications"],
                "weightage": "25%"
            },
            {
                "unit": 2,
                "title": "Core Theories and Applications",
                "topics": ["Advanced concepts", "Practical applications", "Problem solving"],
                "weightage": "50%"
            },
            {
                "unit": 3,
                "title": "Advanced Topics and Projects",
                "topics": ["Specialized areas", "Research projects", "Case studies"],
                "weightage": "25%"
            }
        ]
        return topics

    async def _create_dummy_pdf(self, file_path: Path):
        """Create a dummy PDF file for demonstration purposes"""
        # In a real implementation, this would download the actual PDF from NCERT
        dummy_content = f"""
        NCERT {file_path.stem}
        
        This is a placeholder PDF file for demonstration purposes.
        In a real implementation, this would contain the actual NCERT book content.
        
        Generated on: {datetime.now()}
        """
        
        async with aiofiles.open(file_path, 'w') as f:
            await f.write(dummy_content)

# Initialize NCERT data handler
ncert_data = NCERTData()

# MCP Server endpoints
@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "message": "NCERT MCP Server",
        "version": "1.0.0",
        "endpoints": {
            "syllabus": "/api/syllabus",
            "learning_plan": "/api/learning-plan",
            "course_content": "/api/course-content",
            "books": "/api/books",
            "download_book": "/api/download-book"
        }
    }

@app.post("/api/syllabus")
async def get_syllabus(request: SyllabusRequest):
    """Get syllabus for a specific class and subject"""
    return await ncert_data.get_syllabus(request.class_name, request.subject)

@app.post("/api/learning-plan")
async def get_learning_plan(request: LearningPlanRequest):
    """Get learning plan for a specific class and subject"""
    return await ncert_data.get_learning_plan(request.class_name, request.subject)

@app.post("/api/course-content")
async def get_course_content(request: CourseContentRequest):
    """Get course content for a specific class, subject, and optionally chapter"""
    return await ncert_data.get_course_content(request.class_name, request.subject, request.chapter)

@app.post("/api/books")
async def get_books(request: BookDownloadRequest):
    """Get available books for a specific class and subject"""
    return await ncert_data.get_books(request.class_name, request.subject)

@app.post("/api/download-book")
async def download_book(request: BookDownloadRequest, background_tasks: BackgroundTasks):
    """Download a specific book"""
    download_info = await ncert_data.download_book(request.class_name, request.subject, request.book_type)
    return download_info

@app.get("/api/downloads/{filename:path}")
async def serve_download(filename: str):
    """Serve downloaded files"""
    file_path = ncert_data.download_dir / filename
    if file_path.exists():
        return FileResponse(file_path, filename=filename)
    else:
        raise HTTPException(status_code=404, detail="File not found")

@app.get("/api/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000) 