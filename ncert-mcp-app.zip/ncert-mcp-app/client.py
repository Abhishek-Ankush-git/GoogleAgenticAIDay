import requests
import json
import asyncio
import aiohttp
from typing import Dict, Any, List, Optional
from pathlib import Path
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class NCERTMCPClient:
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url
        self.session = requests.Session()
        self.download_dir = Path("downloads")
        self.download_dir.mkdir(exist_ok=True)

    def health_check(self) -> Dict[str, Any]:
        """Check if the MCP server is running"""
        try:
            response = self.session.get(f"{self.base_url}/api/health")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return {"status": "error", "error": str(e)}

    def get_syllabus(self, class_name: str, subject: Optional[str] = None) -> Dict[str, Any]:
        """Get syllabus for a specific class and subject"""
        try:
            payload = {
                "class_name": class_name,
                "subject": subject
            }
            
            response = self.session.post(f"{self.base_url}/api/syllabus", json=payload)
            response.raise_for_status()
            return response.json()
            
        except Exception as e:
            logger.error(f"Failed to get syllabus: {e}")
            return {"status": "error", "error": str(e)}

    def get_learning_plan(self, class_name: str, subject: str) -> Dict[str, Any]:
        """Get learning plan for a specific class and subject"""
        try:
            payload = {
                "class_name": class_name,
                "subject": subject
            }
            
            response = self.session.post(f"{self.base_url}/api/learning-plan", json=payload)
            response.raise_for_status()
            return response.json()
            
        except Exception as e:
            logger.error(f"Failed to get learning plan: {e}")
            return {"status": "error", "error": str(e)}

    def get_course_content(self, class_name: str, subject: str, chapter: Optional[str] = None) -> Dict[str, Any]:
        """Get course content for a specific class, subject, and optionally chapter"""
        try:
            payload = {
                "class_name": class_name,
                "subject": subject,
                "chapter": chapter
            }
            
            response = self.session.post(f"{self.base_url}/api/course-content", json=payload)
            response.raise_for_status()
            return response.json()
            
        except Exception as e:
            logger.error(f"Failed to get course content: {e}")
            return {"status": "error", "error": str(e)}

    def get_books(self, class_name: str, subject: str) -> Dict[str, Any]:
        """Get available books for a specific class and subject"""
        try:
            payload = {
                "class_name": class_name,
                "subject": subject
            }
            
            response = self.session.post(f"{self.base_url}/api/books", json=payload)
            response.raise_for_status()
            return response.json()
            
        except Exception as e:
            logger.error(f"Failed to get books: {e}")
            return {"status": "error", "error": str(e)}

    def download_book(self, class_name: str, subject: str, book_type: str = "textbook") -> Dict[str, Any]:
        """Download a specific book"""
        try:
            payload = {
                "class_name": class_name,
                "subject": subject,
                "book_type": book_type
            }
            
            response = self.session.post(f"{self.base_url}/api/download-book", json=payload)
            response.raise_for_status()
            return response.json()
            
        except Exception as e:
            logger.error(f"Failed to download book: {e}")
            return {"status": "error", "error": str(e)}

    def download_file(self, filename: str, save_path: Optional[Path] = None) -> bool:
        """Download a file from the server"""
        try:
            if save_path is None:
                save_path = self.download_dir / filename
            
            response = self.session.get(f"{self.base_url}/api/downloads/{filename}", stream=True)
            response.raise_for_status()
            
            save_path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(save_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            logger.info(f"File downloaded successfully: {save_path}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to download file: {e}")
            return False

    def list_available_classes(self) -> List[str]:
        """List available classes"""
        return ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII']

    def list_available_subjects(self) -> List[str]:
        """List available subjects"""
        return [
            'Mathematics', 'Science', 'Social Science', 'English', 'Hindi', 'Sanskrit',
            'Physics', 'Chemistry', 'Biology', 'History', 'Geography', 
            'Political Science', 'Economics'
        ]

    def search_content(self, query: str, class_name: Optional[str] = None, subject: Optional[str] = None) -> List[Dict[str, Any]]:
        """Search for content across all available data"""
        results = []
        
        # Search in syllabus
        if class_name:
            syllabus = self.get_syllabus(class_name, subject)
            if "topics" in syllabus:
                for topic in syllabus["topics"]:
                    if query.lower() in topic.get("title", "").lower():
                        results.append({
                            "type": "syllabus",
                            "class": class_name,
                            "subject": subject,
                            "content": topic
                        })
        
        # Search in books
        if class_name and subject:
            books = self.get_books(class_name, subject)
            if "books" in books:
                for book in books["books"]:
                    if query.lower() in book.get("title", "").lower():
                        results.append({
                            "type": "book",
                            "class": class_name,
                            "subject": subject,
                            "content": book
                        })
        
        return results

class NCERTClientCLI:
    def __init__(self):
        self.client = NCERTMCPClient()
        self.running = True

    def print_menu(self):
        """Print the main menu"""
        print("\n" + "="*50)
        print("NCERT MCP Client - Educational Content Manager")
        print("="*50)
        print("1. Health Check")
        print("2. Get Syllabus")
        print("3. Get Learning Plan")
        print("4. Get Course Content")
        print("5. Get Books")
        print("6. Download Book")
        print("7. Search Content")
        print("8. List Available Classes")
        print("9. List Available Subjects")
        print("0. Exit")
        print("="*50)

    def get_user_input(self, prompt: str, options: Optional[List[str]] = None) -> str:
        """Get user input with optional validation"""
        while True:
            user_input = input(prompt).strip()
            if options is None or user_input in options:
                return user_input
            print(f"Please enter one of: {', '.join(options)}")

    def run(self):
        """Run the CLI application"""
        print("Welcome to NCERT MCP Client!")
        
        # Check server health
        health = self.client.health_check()
        if health.get("status") != "healthy":
            print("Warning: MCP server might not be running. Some features may not work.")
        
        while self.running:
            self.print_menu()
            choice = self.get_user_input("Enter your choice (0-9): ", [str(i) for i in range(10)])
            
            try:
                if choice == "1":
                    self.handle_health_check()
                elif choice == "2":
                    self.handle_get_syllabus()
                elif choice == "3":
                    self.handle_get_learning_plan()
                elif choice == "4":
                    self.handle_get_course_content()
                elif choice == "5":
                    self.handle_get_books()
                elif choice == "6":
                    self.handle_download_book()
                elif choice == "7":
                    self.handle_search_content()
                elif choice == "8":
                    self.handle_list_classes()
                elif choice == "9":
                    self.handle_list_subjects()
                elif choice == "0":
                    self.running = False
                    print("Goodbye!")
                    
            except KeyboardInterrupt:
                print("\nOperation cancelled by user.")
            except Exception as e:
                print(f"Error: {e}")

    def handle_health_check(self):
        """Handle health check"""
        print("\nChecking server health...")
        health = self.client.health_check()
        print(json.dumps(health, indent=2))

    def handle_get_syllabus(self):
        """Handle syllabus request"""
        print("\nGet Syllabus")
        class_name = self.get_user_input("Enter class name: ", self.client.list_available_classes())
        subject = self.get_user_input("Enter subject (or press Enter to skip): ")
        subject = subject if subject else None
        
        print("Fetching syllabus...")
        syllabus = self.client.get_syllabus(class_name, subject)
        print(json.dumps(syllabus, indent=2))

    def handle_get_learning_plan(self):
        """Handle learning plan request"""
        print("\nGet Learning Plan")
        class_name = self.get_user_input("Enter class name: ", self.client.list_available_classes())
        subject = self.get_user_input("Enter subject: ", self.client.list_available_subjects())
        
        print("Fetching learning plan...")
        plan = self.client.get_learning_plan(class_name, subject)
        print(json.dumps(plan, indent=2))

    def handle_get_course_content(self):
        """Handle course content request"""
        print("\nGet Course Content")
        class_name = self.get_user_input("Enter class name: ", self.client.list_available_classes())
        subject = self.get_user_input("Enter subject: ", self.client.list_available_subjects())
        chapter = self.get_user_input("Enter chapter (or press Enter to skip): ")
        chapter = chapter if chapter else None
        
        print("Fetching course content...")
        content = self.client.get_course_content(class_name, subject, chapter)
        print(json.dumps(content, indent=2))

    def handle_get_books(self):
        """Handle books request"""
        print("\nGet Books")
        class_name = self.get_user_input("Enter class name: ", self.client.list_available_classes())
        subject = self.get_user_input("Enter subject: ", self.client.list_available_subjects())
        
        print("Fetching books...")
        books = self.client.get_books(class_name, subject)
        print(json.dumps(books, indent=2))

    def handle_download_book(self):
        """Handle book download"""
        print("\nDownload Book")
        class_name = self.get_user_input("Enter class name: ", self.client.list_available_classes())
        subject = self.get_user_input("Enter subject: ", self.client.list_available_subjects())
        book_type = self.get_user_input("Enter book type (textbook/workbook/teacher_guide): ", 
                                      ["textbook", "workbook", "teacher_guide"])
        
        print("Downloading book...")
        result = self.client.download_book(class_name, subject, book_type)
        print(json.dumps(result, indent=2))

    def handle_search_content(self):
        """Handle content search"""
        print("\nSearch Content")
        query = self.get_user_input("Enter search query: ")
        class_name = self.get_user_input("Enter class name (or press Enter to skip): ", 
                                       [""] + self.client.list_available_classes())
        class_name = class_name if class_name else None
        
        print("Searching content...")
        results = self.client.search_content(query, class_name)
        print(json.dumps(results, indent=2))

    def handle_list_classes(self):
        """Handle list classes"""
        print("\nAvailable Classes:")
        classes = self.client.list_available_classes()
        for i, class_name in enumerate(classes, 1):
            print(f"{i}. Class {class_name}")

    def handle_list_subjects(self):
        """Handle list subjects"""
        print("\nAvailable Subjects:")
        subjects = self.client.list_available_subjects()
        for i, subject in enumerate(subjects, 1):
            print(f"{i}. {subject}")

def main():
    """Main function"""
    cli = NCERTClientCLI()
    cli.run()

if __name__ == "__main__":
    main() 