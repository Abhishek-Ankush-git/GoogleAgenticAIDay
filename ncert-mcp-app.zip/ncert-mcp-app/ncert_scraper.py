import requests
from bs4 import BeautifulSoup
import re
import json
from typing import List, Dict, Any, Optional
from pathlib import Path
import logging
from datetime import datetime
import time
from urllib.parse import urljoin, urlparse
import aiofiles
import asyncio

logger = logging.getLogger(__name__)

class NCERTScraper:
    def __init__(self):
        self.base_url = "https://ncert.nic.in"
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        })
        
        # NCERT website structure
        self.urls = {
            'main': 'https://ncert.nic.in',
            'textbooks': 'https://ncert.nic.in/textbook.php',
            'syllabus': 'https://ncert.nic.in/syllabus.php',
            'e-resources': 'https://ncert.nic.in/e-resources.php',
            'publications': 'https://ncert.nic.in/publications.php'
        }
        
        self.classes = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII']
        self.subjects = ['Mathematics', 'Science', 'Social Science', 'English', 'Hindi', 'Sanskrit', 'Physics', 'Chemistry', 'Biology', 'History', 'Geography', 'Political Science', 'Economics']

    def get_textbooks_page(self) -> Dict[str, Any]:
        """Get the main textbooks page"""
        try:
            response = self.session.get(self.urls['textbooks'])
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extract available classes
            classes_data = []
            class_links = soup.find_all('a', href=re.compile(r'class'))
            
            for link in class_links:
                class_name = link.get_text(strip=True)
                class_url = urljoin(self.base_url, link.get('href', ''))
                classes_data.append({
                    'class_name': class_name,
                    'url': class_url
                })
            
            return {
                'status': 'success',
                'classes': classes_data,
                'total_classes': len(classes_data),
                'scraped_at': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error fetching textbooks page: {e}")
            return {
                'status': 'error',
                'error': str(e),
                'scraped_at': datetime.now().isoformat()
            }

    def get_class_textbooks(self, class_name: str) -> Dict[str, Any]:
        """Get textbooks for a specific class"""
        try:
            # Construct URL for specific class
            class_url = f"{self.urls['textbooks']}?class={class_name}"
            response = self.session.get(class_url)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extract subject-wise textbooks
            subjects_data = []
            subject_links = soup.find_all('a', href=re.compile(r'subject'))
            
            for link in subject_links:
                subject_name = link.get_text(strip=True)
                subject_url = urljoin(self.base_url, link.get('href', ''))
                
                # Get books for this subject
                books = self._get_subject_books(subject_url)
                
                subjects_data.append({
                    'subject': subject_name,
                    'url': subject_url,
                    'books': books
                })
            
            return {
                'class': class_name,
                'subjects': subjects_data,
                'total_subjects': len(subjects_data),
                'scraped_at': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error fetching class textbooks: {e}")
            return {
                'status': 'error',
                'error': str(e),
                'class': class_name,
                'scraped_at': datetime.now().isoformat()
            }

    def _get_subject_books(self, subject_url: str) -> List[Dict[str, Any]]:
        """Get books for a specific subject"""
        try:
            response = self.session.get(subject_url)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            books = []
            book_links = soup.find_all('a', href=re.compile(r'\.pdf|\.epub'))
            
            for link in book_links:
                book_title = link.get_text(strip=True)
                book_url = urljoin(self.base_url, link.get('href', ''))
                file_extension = Path(book_url).suffix.lower()
                
                books.append({
                    'title': book_title,
                    'url': book_url,
                    'format': file_extension[1:] if file_extension else 'pdf',
                    'download_url': book_url
                })
            
            return books
            
        except Exception as e:
            logger.error(f"Error fetching subject books: {e}")
            return []

    def get_syllabus(self, class_name: Optional[str] = None, subject: Optional[str] = None) -> Dict[str, Any]:
        """Get syllabus information"""
        try:
            response = self.session.get(self.urls['syllabus'])
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            syllabus_data = {
                'class': class_name,
                'subject': subject,
                'syllabus_url': self.urls['syllabus'],
                'topics': self._extract_syllabus_content(soup, class_name, subject),
                'scraped_at': datetime.now().isoformat()
            }
            
            return syllabus_data
            
        except Exception as e:
            logger.error(f"Error fetching syllabus: {e}")
            return {
                'status': 'error',
                'error': str(e),
                'scraped_at': datetime.now().isoformat()
            }

    def _extract_syllabus_content(self, soup: BeautifulSoup, class_name: Optional[str] = None, subject: Optional[str] = None) -> List[Dict[str, Any]]:
        """Extract syllabus content from the parsed HTML"""
        topics = []
        
        # Look for syllabus content in the page
        syllabus_sections = soup.find_all(['div', 'section'], class_=re.compile(r'syllabus|curriculum|content'))
        
        for section in syllabus_sections:
            # Extract headings and content
            headings = section.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])
            
            for heading in headings:
                title = heading.get_text(strip=True)
                content = []
                
                # Get content under this heading
                next_elem = heading.find_next_sibling()
                while next_elem and next_elem.name not in ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']:
                    if next_elem.get_text(strip=True):
                        content.append(next_elem.get_text(strip=True))
                    next_elem = next_elem.find_next_sibling()
                
                if title and content:
                    topics.append({
                        'title': title,
                        'content': content,
                        'weightage': self._extract_weightage(title, content)
                    })
        
        # If no structured content found, create generic syllabus
        if not topics:
            topics = self._create_generic_syllabus(class_name, subject)
        
        return topics

    def _extract_weightage(self, title: str, content: List[str]) -> str:
        """Extract weightage information from content"""
        weightage_patterns = [
            r'(\d+)\s*%',
            r'weightage[:\s]*(\d+)',
            r'marks[:\s]*(\d+)'
        ]
        
        for pattern in weightage_patterns:
            for text in content:
                match = re.search(pattern, text, re.IGNORECASE)
                if match:
                    return f"{match.group(1)}%"
        
        return "Not specified"

    def _create_generic_syllabus(self, class_name: Optional[str], subject: Optional[str] = None) -> List[Dict[str, Any]]:
        """Create generic syllabus structure when specific data is not available"""
        generic_topics = [
            {
                'title': 'Introduction and Basic Concepts',
                'content': ['Fundamental principles', 'Historical development', 'Current applications'],
                'weightage': '25%'
            },
            {
                'title': 'Core Theories and Applications',
                'content': ['Advanced concepts', 'Practical applications', 'Problem solving'],
                'weightage': '50%'
            },
            {
                'title': 'Advanced Topics and Projects',
                'content': ['Specialized areas', 'Research projects', 'Case studies'],
                'weightage': '25%'
            }
        ]
        
        return generic_topics

    def download_book(self, book_url: str, download_path: Path) -> Dict[str, Any]:
        """Download a book from NCERT website"""
        try:
            response = self.session.get(book_url, stream=True)
            response.raise_for_status()
            
            # Extract filename from URL or content-disposition
            filename = self._extract_filename(response, book_url)
            file_path = download_path / filename
            
            # Ensure download directory exists
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Download the file
            with open(file_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            download_info = {
                'filename': filename,
                'file_path': str(file_path),
                'file_size': file_path.stat().st_size,
                'download_time': datetime.now().isoformat(),
                'status': 'completed',
                'url': book_url
            }
            
            return download_info
            
        except Exception as e:
            logger.error(f"Error downloading book: {e}")
            return {
                'status': 'error',
                'error': str(e),
                'url': book_url,
                'download_time': datetime.now().isoformat()
            }

    def _extract_filename(self, response: requests.Response, url: str) -> str:
        """Extract filename from response headers or URL"""
        # Try to get filename from content-disposition header
        content_disposition = response.headers.get('content-disposition', '')
        if content_disposition:
            filename_match = re.search(r'filename[^;=\n]*=(([\'"]).*?\2|[^;\n]*)', content_disposition)
            if filename_match:
                filename = filename_match.group(1).strip('"\'')
                return filename
        
        # Extract from URL
        parsed_url = urlparse(url)
        filename = Path(parsed_url.path).name
        if not filename or filename == '':
            filename = f"ncert_book_{int(time.time())}.pdf"
        
        return filename

    def search_books(self, query: str, class_name: Optional[str] = None, subject: Optional[str] = None) -> List[Dict[str, Any]]:
        """Search for books based on query"""
        try:
            # This would involve implementing a search functionality
            # For now, we'll return a mock search result
            search_results = [
                {
                    'title': f'Search result for "{query}"',
                    'class': class_name,
                    'subject': subject,
                    'url': f"{self.urls['textbooks']}?search={query}",
                    'relevance': 'high'
                }
            ]
            
            return search_results
            
        except Exception as e:
            logger.error(f"Error searching books: {e}")
            return []

    def get_publications(self) -> Dict[str, Any]:
        """Get NCERT publications"""
        try:
            response = self.session.get(self.urls['publications'])
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            publications = []
            pub_links = soup.find_all('a', href=re.compile(r'publication|journal|research'))
            
            for link in pub_links:
                title = link.get_text(strip=True)
                url = urljoin(self.base_url, link.get('href', ''))
                
                publications.append({
                    'title': title,
                    'url': url,
                    'type': self._categorize_publication(title)
                })
            
            return {
                'publications': publications,
                'total': len(publications),
                'scraped_at': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error fetching publications: {e}")
            return {
                'status': 'error',
                'error': str(e),
                'scraped_at': datetime.now().isoformat()
            }

    def _categorize_publication(self, title: str) -> str:
        """Categorize publication based on title"""
        title_lower = title.lower()
        
        if any(word in title_lower for word in ['journal', 'research', 'study']):
            return 'research'
        elif any(word in title_lower for word in ['textbook', 'book', 'manual']):
            return 'textbook'
        elif any(word in title_lower for word in ['syllabus', 'curriculum']):
            return 'curriculum'
        else:
            return 'other'

# Example usage
if __name__ == "__main__":
    scraper = NCERTScraper()
    
    # Test the scraper
    print("Testing NCERT Scraper...")
    
    # Get textbooks page
    textbooks_data = scraper.get_textbooks_page()
    print(f"Textbooks data: {json.dumps(textbooks_data, indent=2)}")
    
    # Get syllabus
    syllabus_data = scraper.get_syllabus("X", "Mathematics")
    print(f"Syllabus data: {json.dumps(syllabus_data, indent=2)}")
    
    # Get publications
    publications_data = scraper.get_publications()
    print(f"Publications data: {json.dumps(publications_data, indent=2)}") 