#!/usr/bin/env python3
"""
Test script for NCERT MCP Application
"""

import requests
import json
import time
from pathlib import Path

def test_server_health(base_url="http://localhost:8000"):
    """Test server health endpoint"""
    print("Testing server health...")
    try:
        response = requests.get(f"{base_url}/api/health")
        if response.status_code == 200:
            print("✅ Server is healthy!")
            return True
        else:
            print(f"❌ Server health check failed: {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to server. Make sure the server is running on localhost:8000")
        return False

def test_api_endpoints(base_url="http://localhost:8000"):
    """Test all API endpoints"""
    print("\nTesting API endpoints...")
    
    # Test data
    test_cases = [
        {
            "name": "Get Syllabus",
            "endpoint": "/api/syllabus",
            "method": "POST",
            "data": {"class_name": "X", "subject": "Mathematics"}
        },
        {
            "name": "Get Learning Plan",
            "endpoint": "/api/learning-plan",
            "method": "POST",
            "data": {"class_name": "X", "subject": "Science"}
        },
        {
            "name": "Get Course Content",
            "endpoint": "/api/course-content",
            "method": "POST",
            "data": {"class_name": "X", "subject": "Mathematics", "chapter": "Algebra"}
        },
        {
            "name": "Get Books",
            "endpoint": "/api/books",
            "method": "POST",
            "data": {"class_name": "X", "subject": "Science"}
        },
        {
            "name": "Download Book",
            "endpoint": "/api/download-book",
            "method": "POST",
            "data": {"class_name": "X", "subject": "Mathematics", "book_type": "textbook"}
        }
    ]
    
    results = []
    
    for test_case in test_cases:
        print(f"\nTesting: {test_case['name']}")
        try:
            if test_case['method'] == 'POST':
                response = requests.post(
                    f"{base_url}{test_case['endpoint']}", 
                    json=test_case['data'],
                    headers={'Content-Type': 'application/json'}
                )
            else:
                response = requests.get(f"{base_url}{test_case['endpoint']}")
            
            if response.status_code == 200:
                print(f"✅ {test_case['name']} - Success")
                results.append(True)
            else:
                print(f"❌ {test_case['name']} - Failed (Status: {response.status_code})")
                results.append(False)
                
        except Exception as e:
            print(f"❌ {test_case['name']} - Error: {e}")
            results.append(False)
    
    return results

def test_ncert_scraper():
    """Test the NCERT scraper module"""
    print("\nTesting NCERT Scraper...")
    try:
        from ncert_scraper import NCERTScraper
        
        scraper = NCERTScraper()
        
        # Test textbooks page
        print("Testing textbooks page...")
        textbooks = scraper.get_textbooks_page()
        if textbooks.get('status') == 'success':
            print("✅ Textbooks page - Success")
        else:
            print("❌ Textbooks page - Failed")
        
        # Test syllabus
        print("Testing syllabus...")
        syllabus = scraper.get_syllabus("X", "Mathematics")
        if 'topics' in syllabus:
            print("✅ Syllabus - Success")
        else:
            print("❌ Syllabus - Failed")
        
        # Test publications
        print("Testing publications...")
        publications = scraper.get_publications()
        if 'publications' in publications:
            print("✅ Publications - Success")
        else:
            print("❌ Publications - Failed")
            
        return True
        
    except ImportError:
        print("❌ NCERT scraper module not found")
        return False
    except Exception as e:
        print(f"❌ NCERT scraper test failed: {e}")
        return False

def test_client():
    """Test the CLI client"""
    print("\nTesting CLI Client...")
    try:
        from client import NCERTMCPClient
        
        client = NCERTMCPClient()
        
        # Test health check
        health = client.health_check()
        if health.get('status') == 'healthy':
            print("✅ Client health check - Success")
        else:
            print("❌ Client health check - Failed")
        
        # Test syllabus
        syllabus = client.get_syllabus("X", "Mathematics")
        if 'class' in syllabus:
            print("✅ Client syllabus - Success")
        else:
            print("❌ Client syllabus - Failed")
        
        # Test books
        books = client.get_books("X", "Science")
        if 'books' in books:
            print("✅ Client books - Success")
        else:
            print("❌ Client books - Failed")
            
        return True
        
    except ImportError:
        print("❌ Client module not found")
        return False
    except Exception as e:
        print(f"❌ Client test failed: {e}")
        return False

def test_file_structure():
    """Test if all required files exist"""
    print("\nTesting file structure...")
    
    required_files = [
        "main.py",
        "ncert_scraper.py", 
        "client.py",
        "requirements.txt",
        "README.md"
    ]
    
    all_exist = True
    for file in required_files:
        if Path(file).exists():
            print(f"✅ {file} - Found")
        else:
            print(f"❌ {file} - Missing")
            all_exist = False
    
    return all_exist

def main():
    """Run all tests"""
    print("=" * 50)
    print("NCERT MCP Application Test Suite")
    print("=" * 50)
    
    # Test file structure
    file_structure_ok = test_file_structure()
    
    # Test server health
    server_ok = test_server_health()
    
    # Test API endpoints (only if server is running)
    api_results = []
    if server_ok:
        api_results = test_api_endpoints()
    
    # Test scraper
    scraper_ok = test_ncert_scraper()
    
    # Test client
    client_ok = test_client()
    
    # Summary
    print("\n" + "=" * 50)
    print("TEST SUMMARY")
    print("=" * 50)
    
    print(f"File Structure: {'✅ PASS' if file_structure_ok else '❌ FAIL'}")
    print(f"Server Health: {'✅ PASS' if server_ok else '❌ FAIL'}")
    
    if api_results:
        api_pass_rate = sum(api_results) / len(api_results) * 100
        print(f"API Endpoints: {'✅ PASS' if api_pass_rate >= 80 else '❌ FAIL'} ({api_pass_rate:.1f}%)")
    
    print(f"NCERT Scraper: {'✅ PASS' if scraper_ok else '❌ FAIL'}")
    print(f"CLI Client: {'✅ PASS' if client_ok else '❌ FAIL'}")
    
    # Recommendations
    print("\nRECOMMENDATIONS:")
    if not server_ok:
        print("- Start the server: python main.py")
    if not file_structure_ok:
        print("- Check that all files are in the correct directory")
    if not scraper_ok:
        print("- Check internet connection and NCERT website availability")
    
    print("\nTo start the application:")
    print("1. Start server: python main.py")
    print("2. Use CLI client: python client.py")
    print("3. Or use API directly with curl commands")

if __name__ == "__main__":
    main() 