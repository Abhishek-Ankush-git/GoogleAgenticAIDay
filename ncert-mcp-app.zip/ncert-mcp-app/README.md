# NCERT MCP Server

A Python application with Model Context Protocol (MCP) server that connects to the NCERT website to fetch syllabus, learning plans, course content, books, and download educational materials.

## Features

- **Syllabus Management**: Fetch and organize NCERT syllabus for different classes and subjects
- **Learning Plans**: Get structured learning plans with objectives, activities, and assessments
- **Course Content**: Access detailed course content with chapters, topics, and learning outcomes
- **Book Management**: Browse and download NCERT textbooks, workbooks, and teacher guides
- **Search Functionality**: Search across all educational content
- **RESTful API**: Full REST API for integration with other applications
- **CLI Client**: Interactive command-line interface for easy usage

## Project Structure

```
ncert-mcp-app/
├── main.py              # FastAPI MCP server
├── ncert_scraper.py     # NCERT website scraper
├── client.py            # CLI client application
├── requirements.txt     # Python dependencies
├── README.md           # This file
└── downloads/          # Downloaded files directory
```

## Installation

1. **Clone or create the project directory**:
   ```bash
   mkdir ncert-mcp-app
   cd ncert-mcp-app
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Verify installation**:
   ```bash
   python -c "import fastapi, requests, beautifulsoup4; print('Dependencies installed successfully!')"
   ```

## Usage

### 1. Starting the MCP Server

Start the FastAPI server:

```bash
python main.py
```

The server will start on `http://localhost:8000`

### 2. Using the CLI Client

Run the interactive CLI client:

```bash
python client.py
```

The CLI provides a menu-driven interface with the following options:

- **Health Check**: Verify server status
- **Get Syllabus**: Fetch syllabus for specific class/subject
- **Get Learning Plan**: Get structured learning plans
- **Get Course Content**: Access detailed course content
- **Get Books**: Browse available books
- **Download Book**: Download specific books
- **Search Content**: Search across all content
- **List Classes/Subjects**: View available options

### 3. API Usage

#### Health Check
```bash
curl http://localhost:8000/api/health
```

#### Get Syllabus
```bash
curl -X POST http://localhost:8000/api/syllabus \
  -H "Content-Type: application/json" \
  -d '{"class_name": "X", "subject": "Mathematics"}'
```

#### Get Learning Plan
```bash
curl -X POST http://localhost:8000/api/learning-plan \
  -H "Content-Type: application/json" \
  -d '{"class_name": "X", "subject": "Science"}'
```

#### Get Course Content
```bash
curl -X POST http://localhost:8000/api/course-content \
  -H "Content-Type: application/json" \
  -d '{"class_name": "X", "subject": "Mathematics", "chapter": "Algebra"}'
```

#### Get Books
```bash
curl -X POST http://localhost:8000/api/books \
  -H "Content-Type: application/json" \
  -d '{"class_name": "X", "subject": "Science"}'
```

#### Download Book
```bash
curl -X POST http://localhost:8000/api/download-book \
  -H "Content-Type: application/json" \
  -d '{"class_name": "X", "subject": "Mathematics", "book_type": "textbook"}'
```

## API Endpoints

### Core Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | API information and available endpoints |
| `/api/health` | GET | Server health check |
| `/api/syllabus` | POST | Get syllabus for class/subject |
| `/api/learning-plan` | POST | Get learning plan for class/subject |
| `/api/course-content` | POST | Get course content for class/subject/chapter |
| `/api/books` | POST | Get available books for class/subject |
| `/api/download-book` | POST | Download specific book |
| `/api/downloads/{filename}` | GET | Serve downloaded files |

### Request Models

#### SyllabusRequest
```json
{
  "class_name": "string",
  "subject": "string (optional)"
}
```

#### LearningPlanRequest
```json
{
  "class_name": "string",
  "subject": "string"
}
```

#### CourseContentRequest
```json
{
  "class_name": "string",
  "subject": "string",
  "chapter": "string (optional)"
}
```

#### BookDownloadRequest
```json
{
  "class_name": "string",
  "subject": "string",
  "book_type": "string (default: textbook)"
}
```

## Available Classes and Subjects

### Classes
- I, II, III, IV, V, VI, VII, VIII, IX, X, XI, XII

### Subjects
- Mathematics, Science, Social Science, English, Hindi, Sanskrit
- Physics, Chemistry, Biology, History, Geography, Political Science, Economics

## NCERT Scraper

The `ncert_scraper.py` module provides advanced scraping capabilities:

```python
from ncert_scraper import NCERTScraper

scraper = NCERTScraper()

# Get textbooks page
textbooks = scraper.get_textbooks_page()

# Get class textbooks
class_books = scraper.get_class_textbooks("X")

# Get syllabus
syllabus = scraper.get_syllabus("X", "Mathematics")

# Download book
download_info = scraper.download_book(book_url, download_path)
```

## Configuration

### Environment Variables

You can configure the application using environment variables:

```bash
export NCERT_BASE_URL="https://ncert.nic.in"
export DOWNLOAD_DIR="./downloads"
export LOG_LEVEL="INFO"
```

### Customization

1. **Modify NCERT URLs**: Update the URLs in `ncert_scraper.py` if NCERT changes their website structure
2. **Add New Subjects**: Extend the subjects list in the scraper
3. **Custom Download Path**: Change the download directory in the main application
4. **API Rate Limiting**: Add rate limiting to prevent overwhelming the NCERT servers

## Error Handling

The application includes comprehensive error handling:

- **Network Errors**: Retry mechanisms for failed requests
- **Parsing Errors**: Fallback to generic content when parsing fails
- **Download Errors**: Detailed error messages for failed downloads
- **API Errors**: Proper HTTP status codes and error messages

## Development

### Running Tests

```bash
# Test the scraper
python ncert_scraper.py

# Test the client
python client.py
```

### Adding New Features

1. **New API Endpoints**: Add new endpoints in `main.py`
2. **Enhanced Scraping**: Extend the `NCERTScraper` class
3. **Additional Data Models**: Create new Pydantic models for new data types
4. **CLI Features**: Add new menu options in `client.py`

## Troubleshooting

### Common Issues

1. **Server Not Starting**:
   - Check if port 8000 is available
   - Verify all dependencies are installed
   - Check Python version (3.7+ required)

2. **Scraping Failures**:
   - NCERT website might be down
   - Website structure might have changed
   - Network connectivity issues

3. **Download Failures**:
   - Check disk space
   - Verify file permissions
   - Check network connectivity

### Debug Mode

Enable debug logging:

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is open source and available under the MIT License.

## Disclaimer

This application is for educational purposes. Please respect NCERT's terms of service and use the content responsibly. The application includes rate limiting and respectful scraping practices to avoid overwhelming the NCERT servers.

## Support

For issues and questions:

1. Check the troubleshooting section
2. Review the API documentation
3. Test with the CLI client
4. Check server logs for detailed error messages

## Future Enhancements

- [ ] Real-time NCERT website monitoring
- [ ] Advanced search with filters
- [ ] PDF content extraction
- [ ] Multi-language support
- [ ] Mobile app integration
- [ ] Database storage for caching
- [ ] User authentication and preferences
- [ ] Automated content updates 