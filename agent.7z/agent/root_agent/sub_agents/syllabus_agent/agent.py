"""Conversational syllabus agent with MCP server integration."""

import os
import requests
import json
import re
from typing import Dict, Any, Optional
from dotenv import load_dotenv
from google.adk import Agent
from google.adk.agents.callback_context import CallbackContext
from google.adk.models import LlmResponse
import google.generativeai as genai

# Load environment variables
load_dotenv()

# Configure Gemini API
genai.configure(api_key=os.getenv('GEMINI_API_KEY'))

# Configure proxy settings
proxy_url = os.getenv("HTTP_PROXY") or os.getenv("http_proxy")
if proxy_url:
    os.environ["HTTP_PROXY"] = proxy_url
    os.environ["HTTPS_PROXY"] = (
        os.getenv("HTTPS_PROXY") or os.getenv("https_proxy") or proxy_url
    )

SYLLABUS_PROMPT = """
You are a friendly syllabus assistant! When users ask about curriculum, syllabus, chapters, or NCERT/CBSE content, I'll fetch real data from the MCP server.

I can help with:
📚 NCERT and CBSE curriculum details
📖 Chapter breakdowns and topics  
🎯 Learning outcomes and objectives
📝 Assessment patterns

Just ask me things like:
- "Show me Class 10 Math syllabus"
- "What chapters are in Grade 9 Science?"
- "CBSE English curriculum for Class 8"

I'll get the latest curriculum data for you!

After executing return the control to principal_agent
"""


class SyllabusAgent:
    def __init__(self):
        self.mcp_base_url = "http://localhost:8000"

    def to_roman(self, num: int) -> str:
        values = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1]
        symbols = [
            "M",
            "CM",
            "D",
            "CD",
            "C",
            "XC",
            "L",
            "XL",
            "X",
            "IX",
            "V",
            "IV",
            "I",
        ]
        result = ""
        for i in range(len(values)):
            while num >= values[i]:
                result += symbols[i]
                num -= values[i]
        return result

    def extract_query_info(self, text: str) -> Dict[str, str]:
        """Extract subject and grade from user query"""
        text_lower = text.lower()

        # Extract grade/class
        grade_patterns = [
            r"class\s+(\d+)",
            r"grade\s+(\d+)",
            r"std\s+(\d+)",
            r"(\d+)th\s+class",
            r"(\d+)th\s+grade",
        ]
        grade = None
        for pattern in grade_patterns:
            match = re.search(pattern, text_lower)
            if match:
                grade = f"Grade {match.group(1)}"
                break

        # Extract subject
        subjects = [
            "math",
            "mathematics",
            "science",
            "english",
            "hindi",
            "social",
            "history",
            "geography",
            "physics",
            "chemistry",
            "biology",
        ]
        subject = None
        for subj in subjects:
            if subj in text_lower:
                subject = subj.title()
                if subj == "math":
                    subject = "Mathematics"
                break

        return {"subject": subject, "grade": grade}

    def get_syllabus_from_mcp(
        self, class_name: str, subject: str
    ) -> Optional[Dict[str, Any]]:
        try:
            query_payload = {"class_name": class_name, "subject": subject}

            # Log the query being made to MCP server
            print(f"🔍 MCP Query: POST {self.mcp_base_url}/api/syllabus")
            print(f"📝 Payload: {json.dumps(query_payload, indent=2)}")

            response = requests.post(
                f"{self.mcp_base_url}/api/syllabus",
                json=query_payload,
                headers={"Content-Type": "application/json"},
                timeout=5,
            )

            # Log response status
            print(f"📊 Response Status: {response.status_code}")

            if response.ok:
                result = response.json()
                print(f"✅ MCP Response received successfully")
                print(f"📋 MCP Response Data: {json.dumps(result, indent=2)}")
                return result
            else:
                print(f"❌ MCP Error: {response.status_code} - {response.text}")
                return None

        except Exception as e:
            print(f"🚨 MCP Connection Error: {e}")
            return None

    def format_response(self, data: Dict[str, Any]) -> str:
        """Format MCP response into conversational text"""
        if not data:
            return "Sorry, I couldn't fetch the curriculum data right now. Please try again later."

        response = (
            f"📚 Here's the curriculum for {data.get('subject', 'the subject')}:\n\n"
        )

        if "chapters" in data:
            for i, chapter in enumerate(data["chapters"], 1):
                response += f"{i}. **{chapter.get('title', 'Chapter')}**\n"

                if "topics" in chapter:
                    for topic in chapter["topics"]:
                        response += f"   • {topic}\n"
                response += "\n"

        if "assessmentPattern" in data:
            response += f"📝 **Assessment:** {data['assessmentPattern']}\n"

        return response


def _syllabus_callback(
    callback_context: CallbackContext, llm_response: LlmResponse
) -> LlmResponse:
    """Intercept syllabus queries and call MCP server"""
    print(f"📚 SYLLABUS AGENT CALLBACK TRIGGERED")
    
    if not llm_response or not llm_response.content or not llm_response.content.parts:
        return llm_response

    # Get user input from context
    user_query = ""
    if (
        hasattr(callback_context, "user_content")
        and callback_context.user_content.parts
    ):
        user_query = callback_context.user_content.parts[0].text

    # Check if query is about syllabus
    syllabus_keywords = [
        "syllabus",
        "curriculum",
        "chapters",
        "ncert",
        "cbse",
        "class",
        "grade",
    ]
    if any(keyword in user_query.lower() for keyword in syllabus_keywords):
        agent = SyllabusAgent()
        query_info = agent.extract_query_info(user_query)

        if query_info["subject"] and query_info["grade"]:
            # Convert grade to roman numeral for class_name
            grade_num = int(query_info["grade"].replace("Grade ", ""))
            roman_class_name = agent.to_roman(grade_num)

            print(
                f"🎯 Extracted: Grade {grade_num} -> Roman: {roman_class_name}, Subject: {query_info['subject']}"
            )

            # Call MCP server with roman numeral as class_name
            mcp_data = agent.get_syllabus_from_mcp(
                roman_class_name, query_info["subject"]
            )

            if mcp_data and mcp_data.get('chapters'):
                # Replace AI response with MCP data
                formatted_response = agent.format_response(mcp_data)
                print(f"📤 Final Response Being Sent: {formatted_response[:200]}...")
                llm_response.content.parts[0].text = formatted_response
                print(f"✅ Response replaced with MCP data")
            else:
                # Fallback to Gemini 2.5 Pro
                print(f"⚠️ MCP empty/failed, falling back to Gemini 2.5 Pro")
                genai.configure(api_key=os.getenv('GEMINI_API_KEY'))
                model = genai.GenerativeModel('gemini-2.0-flash-exp')
                fallback_prompt = f"Provide detailed NCERT/CBSE syllabus and curriculum information for Class {grade_num} {query_info['subject']}. Include chapter names, topics, and learning outcomes."
                try:
                    response = model.generate_content(fallback_prompt)
                    llm_response.content.parts[0].text = response.text
                    print(f"✅ Using Gemini 2.5 Pro fallback response")
                except Exception as e:
                    error_msg = f"Sorry, I couldn't find curriculum data for Class {grade_num} {query_info['subject']}."
                    llm_response.content.parts[0].text = error_msg
                    print(f"❌ Gemini fallback failed: {e}")

    return llm_response


# Create syllabus agent with MCP integration
syllabus_agent = Agent(
    model="gemini-1.5-flash",
    name="syllabus_agent",
    instruction=SYLLABUS_PROMPT,
    after_model_callback=_syllabus_callback,
)

# Export as root_agent for ADK web discovery
# root_agent = syllabus_agent
