"""Syllabus Chat Agent Package"""

from .agent import syllabus_agent
