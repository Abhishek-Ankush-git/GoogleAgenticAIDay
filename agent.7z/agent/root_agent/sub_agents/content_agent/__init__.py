"""Syllabus Chat Agent Package"""

from .agent import content_agent
