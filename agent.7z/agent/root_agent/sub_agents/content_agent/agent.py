"""Conversational content agent with MCP server integration."""

import os
import requests
import json
import re
from typing import Dict, Any, Optional
from dotenv import load_dotenv
from google.adk import Agent
from google.adk.agents.callback_context import CallbackContext
from google.adk.models import LlmResponse
import google.generativeai as genai
from . import prompt

# Load environment variables
load_dotenv()

# Configure Gemini API
genai.configure(api_key=os.getenv('GEMINI_API_KEY'))

# Configure proxy settings
proxy_url = os.getenv("HTTP_PROXY") or os.getenv("http_proxy")
if proxy_url:
    os.environ["HTTP_PROXY"] = proxy_url
    os.environ["HTTPS_PROXY"] = (
        os.getenv("HTTPS_PROXY") or os.getenv("https_proxy") or proxy_url
    )


class ContentAgent:
    def __init__(self):
        self.mcp_base_url = "http://localhost:8000"

    def to_roman(self, num: int) -> str:
        values = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1]
        symbols = [
            "M",
            "CM",
            "D",
            "CD",
            "C",
            "XC",
            "L",
            "XL",
            "X",
            "IX",
            "V",
            "IV",
            "I",
        ]
        result = ""
        for i in range(len(values)):
            while num >= values[i]:
                result += symbols[i]
                num -= values[i]
        return result

    def extract_query_info(self, text: str) -> Dict[str, str]:
        """Extract subject, grade, and topic from user query"""
        text_lower = text.lower()

        # Extract grade/class
        grade_patterns = [
            r"class\s+(\d+)",
            r"grade\s+(\d+)",
            r"std\s+(\d+)",
            r"(\d+)th\s+class",
            r"(\d+)th\s+grade",
        ]
        grade = None
        for pattern in grade_patterns:
            match = re.search(pattern, text_lower)
            if match:
                grade = f"Grade {match.group(1)}"
                break

        # Extract subject
        subjects = [
            "math",
            "mathematics",
            "science",
            "english",
            "hindi",
            "social",
            "history",
            "geography",
            "physics",
            "chemistry",
            "biology",
        ]
        subject = None
        for subj in subjects:
            if subj in text_lower:
                subject = subj.title()
                if subj == "math":
                    subject = "Mathematics"
                break

        # Extract topic/chapter
        topic = None
        topic_patterns = [
            r"content\s+(?:for|on)\s+([\w\s]+)",
            r"chapter\s+([\w\s]+)",
            r"topic\s+([\w\s]+)",
        ]
        for pattern in topic_patterns:
            match = re.search(pattern, text_lower)
            if match:
                topic = match.group(1).strip().title()
                break

        return {"subject": subject, "grade": grade, "topic": topic}

    def get_course_content_from_mcp(
        self, class_name: str, subject: str, chapter: str = None
    ) -> Optional[Dict[str, Any]]:
        try:
            query_payload = {
                "class_name": class_name,
                "subject": subject,
                "chapter": chapter,
            }

            print(f"🔍 MCP Query: POST {self.mcp_base_url}/api/course-content")
            print(f"📝 Payload: {json.dumps(query_payload, indent=2)}")

            response = requests.post(
                f"{self.mcp_base_url}/api/course-content",
                json=query_payload,
                headers={"Content-Type": "application/json"},
                timeout=5,
            )

            print(f"📊 Response Status: {response.status_code}")

            if response.ok:
                result = response.json()
                print(f"✅ MCP Response received successfully")
                return result
            else:
                print(f"❌ MCP Error: {response.status_code} - {response.text}")
                return None

        except Exception as e:
            print(f"🚨 MCP Connection Error: {e}")
            return None

    def format_response(self, data: Dict[str, Any]) -> str:
        """Format MCP response into conversational text"""
        if not data:
            return "Sorry, I couldn't fetch the content data right now. Please try again later."

        response = f"📚 Here's the content for {data.get('topic', 'the topic')}:\n\n"

        if "courseContent" in data and isinstance(data["courseContent"], list):
            for i, section in enumerate(data["courseContent"], 1):
                response += f"**{i}. {section.get('activityName', 'Activity')}**\n\n"
                
                if section.get("teacherLedExplanation"):
                    response += f"📖 **Explanation:** {section['teacherLedExplanation']}\n\n"
                
                if section.get("studentExercises"):
                    response += "✏️ **Exercises:**\n"
                    for j, exercise in enumerate(section["studentExercises"], 1):
                        response += f"   {j}. {exercise}\n"
                    response += "\n"
                
                if section.get("flashcards"):
                    response += "🔑 **Key Terms:**\n"
                    for card in section["flashcards"]:
                        response += f"   • **{card.get('term', '')}**: {card.get('definition', '')}\n"
                    response += "\n"

        return response


def _content_callback(
    callback_context: CallbackContext, llm_response: LlmResponse
) -> LlmResponse:
    """Intercept content queries and call MCP server"""
    print(f"📝 CONTENT AGENT CALLBACK TRIGGERED")
    
    if not llm_response or not llm_response.content or not llm_response.content.parts:
        return llm_response

    # Get user input from context
    user_query = ""
    if (
        hasattr(callback_context, "user_content")
        and callback_context.user_content.parts
    ):
        user_query = callback_context.user_content.parts[0].text

    # Check if query is about content generation
    content_keywords = [
        "content",
        "generate",
        "create",
        "chapter",
        "topic",
        "lesson",
        "material",
    ]
    if any(keyword in user_query.lower() for keyword in content_keywords):
        agent = ContentAgent()
        query_info = agent.extract_query_info(user_query)

        if query_info["subject"] and query_info["grade"]:
            # Convert grade to roman numeral for class_name
            grade_num = int(query_info["grade"].replace("Grade ", ""))
            roman_class_name = agent.to_roman(grade_num)

            print(
                f"🎯 Extracted: Grade {grade_num} -> Roman: {roman_class_name}, Subject: {query_info['subject']}, Topic: {query_info['topic']}"
            )

            # Call MCP server
            mcp_data = agent.get_course_content_from_mcp(
                roman_class_name, query_info["subject"], query_info["topic"]
            )

            if mcp_data and mcp_data.get('courseContent'):
                # Replace AI response with MCP data
                formatted_response = agent.format_response(mcp_data)
                llm_response.content.parts[0].text = formatted_response
                print(f"✅ Response replaced with MCP data")
            else:
                # Fallback to Gemini 2.5 Pro
                print(f"⚠️ MCP empty/failed, falling back to Gemini 2.5 Pro")
                genai.configure(api_key=os.getenv('GEMINI_API_KEY'))
                model = genai.GenerativeModel('gemini-2.0-flash-exp')
                fallback_prompt = f"Generate comprehensive educational content for Class {grade_num} {query_info['subject']} on topic: {query_info['topic'] or 'general curriculum'}. Include explanations, key concepts, and practice exercises."
                try:
                    response = model.generate_content(fallback_prompt)
                    llm_response.content.parts[0].text = response.text
                    print(f"✅ Using Gemini 2.5 Pro fallback response")
                except Exception as e:
                    error_msg = f"Sorry, I couldn't generate content for Class {grade_num} {query_info['subject']}."
                    llm_response.content.parts[0].text = error_msg
                    print(f"❌ Gemini fallback failed: {e}")

    return llm_response


# Create content agent with MCP integration
content_agent = Agent(
    model="gemini-1.5-flash",
    name="content_agent",
    instruction=prompt.CONTENT_PROMPT,
    after_model_callback=_content_callback,
)

# Export as root_agent for ADK web discovery
root_agent = content_agent
