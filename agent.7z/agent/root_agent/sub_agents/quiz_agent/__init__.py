"""Quiz and Games Agent Package"""

from .agent import quiz_agent