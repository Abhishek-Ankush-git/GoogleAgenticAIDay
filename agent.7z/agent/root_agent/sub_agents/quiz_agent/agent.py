"""Quiz and games generation agent for interactive learning."""

import os
import re
import json
from dotenv import load_dotenv
from google.adk import Agent
from google.adk.agents.callback_context import CallbackContext
from google.adk.models import LlmResponse
import google.generativeai as genai

load_dotenv()

# Configure Gemini API
genai.configure(api_key=os.getenv('GEMINI_API_KEY'))

# Configure proxy settings
proxy_url = os.getenv("HTTP_PROXY") or os.getenv("http_proxy")
if proxy_url:
    os.environ["HTTP_PROXY"] = proxy_url
    os.environ["HTTPS_PROXY"] = (
        os.getenv("HTTPS_PROXY") or os.getenv("https_proxy") or proxy_url
    )

QUIZ_PROMPT = """
You are an interactive quiz generator that creates educational assessments and tests.

I can create:
🧩 Multiple choice quizzes
🎯 True/False questions  
📝 Fill-in-the-blank exercises
📊 Short answer questions
🎓 Assessment tests
📋 Practice exams

Simply tell me the subject and grade level, and I'll create comprehensive quizzes!
"""


class QuizAgent:
    def __init__(self):
        pass

    def detect_quiz_request(self, text: str) -> dict:
        """Detect quiz and game generation requests"""
        text_lower = text.lower()
        
        # Quiz keywords
        quiz_keywords = ["quiz", "test", "question", "mcq", "multiple choice"]
        quiz_match = any(keyword in text_lower for keyword in quiz_keywords)
        
        # Remove game detection from quiz agent
        
        # Specific types
        types = {
            "mcq": any(word in text_lower for word in ["mcq", "multiple choice", "choice"]),
            "true_false": any(word in text_lower for word in ["true false", "true/false", "t/f"]),
            "fill_blank": any(word in text_lower for word in ["fill", "blank", "complete"]),
            "word_game": any(word in text_lower for word in ["word", "crossword", "puzzle"]),
            "general": True
        }
        
        quiz_type = "general"
        for type_name, match in types.items():
            if match:
                quiz_type = type_name
                break
        
        return {
            "is_quiz_request": quiz_match,
            "quiz_type": quiz_type,
            "is_interactive": quiz_match
        }

    def generate_quiz(self, content: str, quiz_type: str, grade: str = "") -> str:
        """Generate quiz using Gemini"""
        try:
            model = genai.GenerativeModel('gemini-2.0-flash-exp')
            
            if quiz_type == "mcq":
                prompt = f"""Create 10 multiple choice questions based on this content. Format:
Q1. [Question]
A) [Option 1]
B) [Option 2] 
C) [Option 3]
D) [Option 4]
Answer: [Correct option]

Grade level: {grade}
Content: {content}"""
            
            elif quiz_type == "true_false":
                prompt = f"""Create 10 True/False questions based on this content. Format:
Q1. [Statement]
Answer: True/False
Explanation: [Brief explanation]

Grade level: {grade}
Content: {content}"""
            
            elif quiz_type == "fill_blank":
                prompt = f"""Create 10 fill-in-the-blank questions based on this content. Format:
Q1. [Sentence with _____ blanks]
Answer: [Correct word/phrase]

Grade level: {grade}
Content: {content}"""
            
            else:
                prompt = f"""Create a mixed quiz with 10 questions (MCQ, True/False, Fill-in-blanks) based on this content.
Grade level: {grade}
Content: {content}"""
            
            response = model.generate_content(prompt)
            return response.text
            
        except Exception as e:
            print(f"❌ Quiz generation failed: {e}")
            return f"Quiz questions for: {content}"



    def format_quiz_response(self, quiz_content: str, quiz_type: str) -> str:
        """Format the quiz response"""
        return f"""🧩 **Interactive Quiz Generated**

**Type:** {quiz_type.replace('_', ' ').title()}

{quiz_content}

**Instructions:**
- Read each question carefully
- Choose the best answer
- Check your answers at the end
- Review explanations for better understanding

**Study Tips:**
- Take your time with each question
- Eliminate obviously wrong answers first
- Review the content if you're unsure"""




def _quiz_callback(
    callback_context: CallbackContext, llm_response: LlmResponse
) -> LlmResponse:
    """Handle quiz and game generation requests"""
    print(f"🧩 QUIZ AGENT CALLBACK TRIGGERED")
    
    if not llm_response or not llm_response.content or not llm_response.content.parts:
        return llm_response

    # Get user input
    user_query = ""
    if (
        hasattr(callback_context, "user_content")
        and callback_context.user_content.parts
    ):
        user_query = callback_context.user_content.parts[0].text

    agent = QuizAgent()
    quiz_info = agent.detect_quiz_request(user_query)
    
    if quiz_info["is_interactive"]:
        print(f"🧩 Interactive request detected: Quiz={quiz_info['is_quiz_request']}, Game={quiz_info['is_game_request']}")
        
        # Get content to create quiz/game from
        content_to_use = llm_response.content.parts[0].text
        
        # Extract grade if mentioned
        grade_match = re.search(r'(class|grade)\s+(\d+)', user_query.lower())
        grade = f"Grade {grade_match.group(2)}" if grade_match else ""
        
        quiz_content = agent.generate_quiz(content_to_use, quiz_info["quiz_type"], grade)
        formatted_response = agent.format_quiz_response(quiz_content, quiz_info["quiz_type"])
        
        llm_response.content.parts[0].text = formatted_response
        print(f"✅ Interactive content generated")

    return llm_response


# Create quiz agent
quiz_agent = Agent(
    model="gemini-1.5-flash",
    name="quiz_agent",
    instruction=QUIZ_PROMPT,
    # after_model_callback=_quiz_callback,
)

# Export as root_agent
# root_agent = quiz_agent