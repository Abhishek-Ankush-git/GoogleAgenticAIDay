"""Accessibility agent for text-to-speech and disability support."""

import os
import re
from dotenv import load_dotenv
from google.adk import Agent
from google.adk.agents.callback_context import CallbackContext
from google.adk.models import LlmResponse
import google.generativeai as genai

load_dotenv()

# Configure Gemini API
genai.configure(api_key=os.getenv('GEMINI_API_KEY'))

# Configure proxy settings
proxy_url = os.getenv("HTTP_PROXY") or os.getenv("http_proxy")
if proxy_url:
    os.environ["HTTP_PROXY"] = proxy_url
    os.environ["HTTPS_PROXY"] = (
        os.getenv("HTTPS_PROXY") or os.getenv("https_proxy") or proxy_url
    )

ACCESSIBILITY_PROMPT = """
You are an accessibility assistant that makes educational content accessible for people with disabilities.

You provide:
🔊 **Text-to-Speech**: Audio descriptions and speech instructions
♿ **Dyslexia Support**: Simplified text, phonetic breakdowns, visual formatting
👁️ **Visual Impairment Support**: Detailed descriptions, structured navigation
🧠 **Learning Difficulties**: Simplified explanations, step-by-step breakdowns

You adapt content for different accessibility needs while maintaining educational value.
"""


class AccessibilityAgent:
    def __init__(self):
        pass

    def detect_accessibility_request(self, text: str) -> dict:
        """Detect accessibility needs from user query"""
        text_lower = text.lower()
        
        # Text-to-speech keywords
        tts_keywords = ["text to speech", "tts", "read aloud", "audio", "voice", "speak"]
        tts_match = any(keyword in text_lower for keyword in tts_keywords)
        
        # Dyslexia support keywords
        dyslexia_keywords = ["dyslexia", "dyslexic", "reading difficulty", "phonetic"]
        dyslexia_match = any(keyword in text_lower for keyword in dyslexia_keywords)
        
        # Visual impairment keywords
        visual_keywords = ["blind", "visually impaired", "screen reader", "describe"]
        visual_match = any(keyword in text_lower for keyword in visual_keywords)
        
        # Learning difficulties keywords
        learning_keywords = ["learning difficulty", "simple", "easy", "step by step"]
        learning_match = any(keyword in text_lower for keyword in learning_keywords)
        
        return {
            "tts": tts_match,
            "dyslexia": dyslexia_match,
            "visual": visual_match,
            "learning": learning_match,
            "is_accessibility": any([tts_match, dyslexia_match, visual_match, learning_match])
        }

    def format_for_tts(self, content: str) -> str:
        """Format content for text-to-speech"""
        try:
            model = genai.GenerativeModel('gemini-2.0-flash-exp')
            prompt = f"""Format this educational content for text-to-speech reading. Add pronunciation guides for difficult words, break into natural speech segments, and include audio cues:

{content}"""
            
            response = model.generate_content(prompt)
            return f"🔊 **Text-to-Speech Format:**\n\n{response.text}\n\n*Note: Use screen reader or TTS software to hear this content*"
        except Exception as e:
            return f"🔊 **Audio Format Available**\n\n{content}\n\n*Use your device's text-to-speech feature to hear this content*"

    def format_for_dyslexia(self, content: str) -> str:
        """Format content for dyslexia support"""
        try:
            model = genai.GenerativeModel('gemini-2.0-flash-exp')
            prompt = f"""Adapt this educational content for dyslexic learners. Use:
- Short sentences and paragraphs
- Simple vocabulary with phonetic breakdowns
- Clear structure with bullet points
- Avoid complex formatting

{content}"""
            
            response = model.generate_content(prompt)
            return f"📖 **Dyslexia-Friendly Format:**\n\n{response.text}"
        except Exception as e:
            return f"📖 **Simplified Format:**\n\n{self._simplify_text(content)}"

    def format_for_visual_impairment(self, content: str) -> str:
        """Format content for visually impaired users"""
        try:
            model = genai.GenerativeModel('gemini-2.0-flash-exp')
            prompt = f"""Adapt this educational content for visually impaired learners. Include:
- Detailed descriptions of any visual elements
- Clear navigation structure
- Screen reader friendly formatting
- Audio descriptions where needed

{content}"""
            
            response = model.generate_content(prompt)
            return f"👁️ **Screen Reader Optimized:**\n\n{response.text}"
        except Exception as e:
            return f"👁️ **Accessible Format:**\n\n{content}\n\n*Content optimized for screen readers*"

    def format_for_learning_difficulties(self, content: str) -> str:
        """Format content for learning difficulties"""
        try:
            model = genai.GenerativeModel('gemini-2.0-flash-exp')
            prompt = f"""Simplify this educational content for learners with learning difficulties. Use:
- Very simple language
- Step-by-step explanations
- Clear examples
- Repetition of key concepts
- Visual organization

{content}"""
            
            response = model.generate_content(prompt)
            return f"🧠 **Easy Learning Format:**\n\n{response.text}"
        except Exception as e:
            return f"🧠 **Simplified Learning:**\n\n{self._simplify_text(content)}"

    def _simplify_text(self, text: str) -> str:
        """Basic text simplification fallback"""
        # Break long sentences, add bullet points
        sentences = text.split('. ')
        simplified = []
        for sentence in sentences:
            if len(sentence) > 50:
                simplified.append(f"• {sentence.strip()}")
            else:
                simplified.append(sentence.strip())
        return '\n'.join(simplified)


def _accessibility_callback(
    callback_context: CallbackContext, llm_response: LlmResponse
) -> LlmResponse:
    """Handle accessibility requests"""
    print(f"♿ ACCESSIBILITY AGENT CALLBACK TRIGGERED")
    
    if not llm_response or not llm_response.content or not llm_response.content.parts:
        return llm_response

    # Get user input
    user_query = ""
    if (
        hasattr(callback_context, "user_content")
        and callback_context.user_content.parts
    ):
        user_query = callback_context.user_content.parts[0].text

    agent = AccessibilityAgent()
    accessibility_needs = agent.detect_accessibility_request(user_query)
    
    if accessibility_needs["is_accessibility"]:
        print(f"♿ Accessibility needs detected: {accessibility_needs}")
        
        # Get content to make accessible (assume it's the current response or extract from query)
        content_to_adapt = llm_response.content.parts[0].text
        
        # Apply accessibility formatting based on needs
        if accessibility_needs["tts"]:
            adapted_content = agent.format_for_tts(content_to_adapt)
        elif accessibility_needs["dyslexia"]:
            adapted_content = agent.format_for_dyslexia(content_to_adapt)
        elif accessibility_needs["visual"]:
            adapted_content = agent.format_for_visual_impairment(content_to_adapt)
        elif accessibility_needs["learning"]:
            adapted_content = agent.format_for_learning_difficulties(content_to_adapt)
        else:
            adapted_content = content_to_adapt
        
        llm_response.content.parts[0].text = adapted_content
        print(f"✅ Content adapted for accessibility")

    return llm_response


# Create accessibility agent
accessibility_agent = Agent(
    model="gemini-1.5-flash",
    name="accessibility_agent",
    instruction=ACCESSIBILITY_PROMPT,
    after_model_callback=_accessibility_callback,
)

# Export as root_agent
root_agent = accessibility_agent