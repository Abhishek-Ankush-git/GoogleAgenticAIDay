"""Translation agent for multilingual educational content."""

import os
import re
from dotenv import load_dotenv
from google.adk import Agent
from google.adk.agents.callback_context import CallbackContext
from google.adk.models import LlmResponse
import google.generativeai as genai

load_dotenv()

# Configure Gemini API
genai.configure(api_key=os.getenv('GEMINI_API_KEY'))

# Configure proxy settings
proxy_url = os.getenv("HTTP_PROXY") or os.getenv("http_proxy")
if proxy_url:
    os.environ["HTTP_PROXY"] = proxy_url
    os.environ["HTTPS_PROXY"] = (
        os.getenv("HTTPS_PROXY") or os.getenv("https_proxy") or proxy_url
    )

TRANSLATION_PROMPT = """
You are a multilingual educational content translator. You can translate educational materials between languages while maintaining academic accuracy and cultural context.

Supported languages:
- English
- Hindi
- Spanish
- French
- German
- Marathi
- Tamil
- Telugu
- Bengali

You preserve:
- Technical terms and concepts
- Educational structure and formatting
- Grade-appropriate language level
- Cultural context where relevant

Simply specify the target language and provide the content to translate!
"""


class TranslationAgent:
    def __init__(self):
        pass

    def detect_language(self, text: str) -> str:
        """Detect source language from text"""
        # Simple language detection patterns
        if re.search(r'[अ-ह]', text):
            return "Hindi"
        elif re.search(r'[ñáéíóú]', text):
            return "Spanish"
        elif re.search(r'[àâäéèêëïîôöùûüÿç]', text):
            return "French"
        elif re.search(r'[äöüß]', text):
            return "German"
        else:
            return "English"

    def extract_translation_info(self, text: str) -> dict:
        """Extract translation request details"""
        text_lower = text.lower()
        
        # Extract target language
        languages = ["hindi", "english", "spanish", "french", "german", "marathi", "tamil", "telugu", "bengali"]
        target_lang = None
        
        for lang in languages:
            if f"to {lang}" in text_lower or f"in {lang}" in text_lower:
                target_lang = lang.title()
                break
        
        # Extract translate keywords
        translate_keywords = ["translate", "translation", "convert"]
        is_translation = any(keyword in text_lower for keyword in translate_keywords)
        
        return {"target_language": target_lang, "is_translation": is_translation}

    def translate_content(self, content: str, target_language: str) -> str:
        """Translate content using Gemini"""
        try:
            model = genai.GenerativeModel('gemini-2.0-flash-exp')
            prompt = f"""Translate the following educational content to {target_language}. 
            Maintain academic accuracy, proper formatting, and grade-appropriate language:

            {content}"""
            
            response = model.generate_content(prompt)
            return response.text
        except Exception as e:
            print(f"❌ Translation failed: {e}")
            return f"Translation to {target_language} failed. Please try again."


def _translation_callback(
    callback_context: CallbackContext, llm_response: LlmResponse
) -> LlmResponse:
    """Handle translation requests"""
    print(f"🌐 TRANSLATION AGENT CALLBACK TRIGGERED")
    
    if not llm_response or not llm_response.content or not llm_response.content.parts:
        return llm_response

    # Get user input
    user_query = ""
    if (
        hasattr(callback_context, "user_content")
        and callback_context.user_content.parts
    ):
        user_query = callback_context.user_content.parts[0].text

    # Check if it's a translation request
    agent = TranslationAgent()
    translation_info = agent.extract_translation_info(user_query)
    
    if translation_info["is_translation"] and translation_info["target_language"]:
        print(f"🌐 Translation request detected: {translation_info['target_language']}")
        
        # Extract content to translate (assume it's after "translate" keyword)
        content_match = re.search(r'translate[:\s]+(.*)', user_query, re.IGNORECASE | re.DOTALL)
        if content_match:
            content_to_translate = content_match.group(1).strip()
        else:
            content_to_translate = user_query
        
        # Perform translation
        translated_content = agent.translate_content(content_to_translate, translation_info["target_language"])
        
        # Format response
        source_lang = agent.detect_language(content_to_translate)
        formatted_response = f"🌐 **Translation from {source_lang} to {translation_info['target_language']}:**\n\n{translated_content}"
        
        llm_response.content.parts[0].text = formatted_response
        print(f"✅ Translation completed")

    return llm_response


# Create translation agent
translation_agent = Agent(
    model="gemini-1.5-flash",
    name="translation_agent",
    instruction=TRANSLATION_PROMPT,
    after_model_callback=_translation_callback,
)

# Export as root_agent
root_agent = translation_agent