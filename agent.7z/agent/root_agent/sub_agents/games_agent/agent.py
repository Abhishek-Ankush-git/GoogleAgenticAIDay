"""Educational games generation agent for interactive learning."""

import os
import re
from dotenv import load_dotenv
from google.adk import Agent
from google.adk.agents.callback_context import CallbackContext
from google.adk.models import LlmResponse
import google.generativeai as genai

load_dotenv()

# Configure Gemini API
genai.configure(api_key=os.getenv('GEMINI_API_KEY'))

# Configure proxy settings
proxy_url = os.getenv("HTTP_PROXY") or os.getenv("http_proxy")
if proxy_url:
    os.environ["HTTP_PROXY"] = proxy_url
    os.environ["HTTPS_PROXY"] = (
        os.getenv("HTTPS_PROXY") or os.getenv("https_proxy") or proxy_url
    )

GAMES_PROMPT = """
You are an educational games generator that creates fun, interactive learning activities.

I can create:
🎮 Educational games and puzzles
🧩 Word games and crosswords
🎯 Interactive challenges
🎲 Memory games
🏆 Competition-based activities
🎪 Role-play scenarios

Simply tell me the subject and grade level, and I'll create engaging learning games!
"""


class GamesAgent:
    def __init__(self):
        pass

    def detect_game_request(self, text: str) -> dict:
        """Detect game generation requests"""
        text_lower = text.lower()
        
        # Game keywords
        game_keywords = ["game", "puzzle", "challenge", "activity", "interactive", "play"]
        game_match = any(keyword in text_lower for keyword in game_keywords)
        
        # Game types
        word_game = any(word in text_lower for word in ["word", "crossword", "scramble"])
        memory_game = any(word in text_lower for word in ["memory", "matching", "pairs"])
        puzzle_game = any(word in text_lower for word in ["puzzle", "riddle", "brain"])
        role_play = any(word in text_lower for word in ["role", "scenario", "simulation"])
        
        game_type = "general"
        if word_game:
            game_type = "word_game"
        elif memory_game:
            game_type = "memory_game"
        elif puzzle_game:
            game_type = "puzzle_game"
        elif role_play:
            game_type = "role_play"
        
        return {
            "is_game_request": game_match,
            "game_type": game_type
        }

    def generate_game(self, content: str, game_type: str, grade: str = "") -> str:
        """Generate educational games using Gemini"""
        try:
            model = genai.GenerativeModel('gemini-2.0-flash-exp')
            
            if game_type == "word_game":
                prompt = f"""Create word games based on this content:
1. Word Search (15 key terms with grid)
2. Crossword puzzle (10 clues)
3. Word scramble (10 terms)
4. Rhyming game

Grade level: {grade}
Content: {content}"""
            
            elif game_type == "memory_game":
                prompt = f"""Create memory games based on this content:
1. Matching pairs (20 cards)
2. Memory sequence game
3. Concentration game rules
4. Flash memory challenges

Grade level: {grade}
Content: {content}"""
            
            elif game_type == "puzzle_game":
                prompt = f"""Create puzzle games based on this content:
1. Logic puzzles (5 problems)
2. Brain teasers
3. Pattern recognition games
4. Problem-solving challenges

Grade level: {grade}
Content: {content}"""
            
            elif game_type == "role_play":
                prompt = f"""Create role-play games based on this content:
1. Character scenarios (5 roles)
2. Simulation activities
3. Interactive storytelling
4. Group collaboration games

Grade level: {grade}
Content: {content}"""
            
            else:
                prompt = f"""Create 5 different educational games based on this content:
1. Interactive group activity
2. Individual challenge
3. Team competition
4. Creative expression game
5. Problem-solving activity

Make them fun and engaging for the grade level.
Grade level: {grade}
Content: {content}"""
            
            response = model.generate_content(prompt)
            return response.text
            
        except Exception as e:
            print(f"❌ Game generation failed: {e}")
            return f"Educational games for: {content}"

    def format_game_response(self, game_content: str, game_type: str) -> str:
        """Format the game response"""
        return f"""🎮 **Educational Games Generated**

**Type:** {game_type.replace('_', ' ').title()}

{game_content}

**Game Instructions:**
- Read rules carefully before starting
- Work individually or in teams as specified
- Keep score to add competition
- Focus on learning while having fun

**Benefits:**
- Reinforces learning through play
- Improves retention and engagement
- Develops problem-solving skills
- Encourages collaboration and creativity

**Tips for Teachers:**
- Adapt difficulty based on student level
- Use as review or assessment tool
- Encourage peer learning
- Celebrate participation and effort"""


def _games_callback(
    callback_context: CallbackContext, llm_response: LlmResponse
) -> LlmResponse:
    """Handle game generation requests"""
    print(f"🎮 GAMES AGENT CALLBACK TRIGGERED")
    
    if not llm_response or not llm_response.content or not llm_response.content.parts:
        return llm_response

    # Get user input
    user_query = ""
    if (
        hasattr(callback_context, "user_content")
        and callback_context.user_content.parts
    ):
        user_query = callback_context.user_content.parts[0].text

    agent = GamesAgent()
    game_info = agent.detect_game_request(user_query)
    
    if game_info["is_game_request"]:
        print(f"🎮 Game request detected: {game_info['game_type']}")
        
        # Get content to create games from
        content_to_use = llm_response.content.parts[0].text
        
        # Extract grade if mentioned
        grade_match = re.search(r'(class|grade)\s+(\d+)', user_query.lower())
        grade = f"Grade {grade_match.group(2)}" if grade_match else ""
        
        game_content = agent.generate_game(content_to_use, game_info["game_type"], grade)
        formatted_response = agent.format_game_response(game_content, game_info["game_type"])
        
        llm_response.content.parts[0].text = formatted_response
        print(f"✅ Games generated")

    return llm_response


# Create games agent
games_agent = Agent(
    model="gemini-1.5-flash",
    name="games_agent",
    instruction=GAMES_PROMPT,
    # after_model_callback=_games_callback,
)

# Export as root_agent
# root_agent = games_agent