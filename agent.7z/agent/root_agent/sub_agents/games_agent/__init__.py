"""Games Agent Package"""

from .agent import games_agent