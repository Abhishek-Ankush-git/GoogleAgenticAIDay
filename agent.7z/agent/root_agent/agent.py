# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""LLM Auditor for verifying & refining LLM-generated answers using the web."""
# from google.adk.agents import LlmAgent
from google.adk.agents import SequentialAgent, BaseAgent, LlmAgent, Agent
# from google.adk.tasks import task
# from google.adk.tasks import task
# from a2a.types import Task
from fastapi import UploadFile
import os

from .sub_agents.accessibility_agent import accessibility_agent
from .sub_agents.content_agent import content_agent
from .sub_agents.copy_checker import copy_checker
from .sub_agents.critic import critic_agent
from .sub_agents.games_agent import games_agent
from .sub_agents.quiz_agent import quiz_agent
from .sub_agents.reviser import reviser_agent
from .sub_agents.syllabus_agent import syllabus_agent
from .sub_agents.translation_agent import translation_agent


# from .sub_agents.image import image_generation_agent
# UPLOAD_DIR = "./uploads"
# os.makedirs(UPLOAD_DIR, exist_ok=True)

# def handle_upload(file):
#     # manually handle file
#     #     """Upload and store a file on the server."""
#     try:
#         file_location = os.path.join(UPLOAD_DIR, file.filename)
#         with open(file_location, "wb") as f:
#             f.write(file.file.read())
#         return {"status": "success", "path": file_location}
#     except Exception as e:
#         return {"status": "error", "message": str(e)}
#
# fu_agent = BaseAgent(name="file_upload_agent")
# fu_agent.register_task(name="handle_upload", func=handle_upload)

supervisor_agent = LlmAgent(
    name='principal_agent',
    # description=(
    #     'Evaluates LLM-generated answers, verifies actual accuracy using the'
    #     ' web, and refines the response to ensure alignment with real-world'
    #     ' knowledge.'
    # ),
    description=(
        ' Redirect the request to right agent and Evaluates LLM-generated answers, verifies actual accuracy using the'
        ' web, and refines the response to ensure alignment with real-world knowledge.'
        'You are a Supervisor Agent. Your job is to analyze each user prompt and decide which specialized sub-agent should handle it and take back control after response from agent'
        'If any information is not available by above , use google search to find the answer and add disclaimer for same that specialized agent is not available for this query, so using google search to find the answer.'
        'If any query is related to vulgar, abusive or violent content, please reject the query and inform the user that such queries are not allowed.'
        'Sub-agents available:'
        '- copy_checker : is expert for evaluation of answer sheets and other types of evaluation tasks.'
        '- reviser_agent : is a fact checker type of agent, who is capabale of verifying the accuracy of the answer and revising it if necessary.'
        '- critic_agent : fallback agent capable of handling all the queries that failed to be handled from any other agent'
        '- syllabus_agent : is agent capable of getting all the cbse syllabus related syllabus and learning plans based on subject and class, if any other board query comes up other than cbse or ncert, please answer as will be available soon'
        '- translation_agent : is agent capable of translating the content to any Indian language or english language.'
        '- accessibility_agent : is agent capable of making different type of accessibility requests like text to speech, dyslexia friendly, visual impairment friendly, easy learning format etc. It can also handle any other accessibility request.'
        '- content_agent : is agent capable of generating the content for any subject and class, it can also handle any other content generation request. it is type of superset of of syllabus_agent and can handle any content generation request related to syllabus or learning plans.'
        '- games_agent : is agent capable of generating educational games and activities based on the content provided by content_agent or syllabus_agent.'
        '- quiz_agent : is agent capable of generating quizzes and question papers based on the content provided by content_agent or syllabus_agent.'
    ),
    sub_agents=[critic_agent, reviser_agent, copy_checker,
                syllabus_agent, translation_agent, accessibility_agent,
                content_agent, quiz_agent, games_agent],
    tools=[],
    model="gemini-2.5-flash"
)

root_agent = supervisor_agent